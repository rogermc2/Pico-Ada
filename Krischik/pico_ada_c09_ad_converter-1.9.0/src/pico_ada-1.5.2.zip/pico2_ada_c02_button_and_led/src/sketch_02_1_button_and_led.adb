--------------------------------------------------------------- {{{1 ----------
--: Copyright © 2026 … 2026 Martin Krischik «krischik@users.sourceforge.net»
------------------------------------------------------------------------------
--: This library is free software; you can redistribute it and/or modify it
--: under the terms of the GNU Library General Public License as published by
--: the Free Software Foundation; either version 2 of the License, or (at your
--: option) any later version.
--:
--: This library is distributed in the hope that it will be useful, but
--: WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
--: or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Library General Public
--: License for more details.
--:
--: You should have received a copy of the GNU Library General Public License
--: along with this library; if not, write to the Free Software Foundation,
--: Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
--------------------------------------------------------------- }}}1 ----------
pragma License (Modified_Gpl);
pragma Ada_2022;
pragma Extensions_Allowed (On);

with Pico.UART_IO;
with Pico;
with RP.GPIO;

---
--  switch LED sample from Chapter 2.1 from the Freenove C-Tutorial Chapter 2.1
--
procedure Sketch_02_1_Button_And_Led with
   No_Return
is
   pragma Debug (Pico.UART_IO.Initialise);
   pragma Debug (Pico.UART_IO.Put_Line ("+ Sketch_04_1_Breathing_Light"));

   ---
   --  Use GP 15 for the external LED
   --
   LED    : RP.GPIO.GPIO_Point renames Pico.GP15;
   ---
   --  Use GP 13 for the external Button
   --
   Button : RP.GPIO.GPIO_Point renames Pico.GP13;
begin
   pragma Debug (Pico.UART_IO.Put_Line ("> Initialise"));
   LED.Configure (RP.GPIO.Output);
   Button.Configure (RP.GPIO.Input);

   pragma Debug (Pico.UART_IO.Put_Line ("> Starting main loop"));
   loop
      --  pressed button is low aka false.
      if Button.Get then
         --  clear / switch off when button is high
         LED.Clear;
      else
         --  set / switch in when button is low
         LED.Set;
      end if;

      --  never busy wait in a tight loop
      delay 0.02;
   end loop;
end Sketch_02_1_Button_And_Led;

---------------------------------------------------------------- {{{ ----------
--: vim: set textwidth=120 nowrap tabstop=8 shiftwidth=3 softtabstop=3 expandtab :
--: vim: set filetype=ada fileencoding=utf-8 fileformat=unix foldmethod=marker :
--: vim: set spell spelllang=en_gb :
